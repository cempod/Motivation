package com.cempod.motivation20;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.transition.TransitionManager;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
ArrayList<Task> taskList = new ArrayList<Task>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        taskList.add(new Task("Задачи на сегодня",true));
        taskList.add(new Task("Задача", false, false, 999, 0 , 0));
        taskList.add(new Task("Задача", true, false, 999, 0 , 0));
        taskList.add(new Task("Задача", false, false, 999, 0 , 0));
        taskList.add(new Task("Задача", false, false, 999, 0 , 0));
        taskList.add(new Task("Задача", false, false, 999, 0 , 0));
        taskList.add(new Task("Ежедневные задачи",true));
        taskList.add(new Task("Задача", false, false, 999, 0 , 0));
        taskList.add(new Task("Задача", false, false, 999, 0 , 0));
        taskList.add(new Task("Задача", true, false, 999, 0 , 0));
        taskList.add(new Task("Задача", false, false, 999, 0 , 0));
        taskList.add(new Task("Задача", true, false, 999, 0 , 0));
        ListView listView = findViewById(R.id.listView);
        MainAdapter mainAdapter = new MainAdapter(this,R.layout.simple_task_card,taskList,listView);
        listView.setAdapter(mainAdapter);
        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomMenu);
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                taskList.add(new Task("Задача", true, false, 999, 0 , 0));
                mainAdapter.notifyDataSetChanged();
                return false;
            }
        });
    }
}
package com.cempod.motivation20;

public class Task {
    private Boolean isDivider;
    private String task;
    private boolean isComplete;
    private boolean isCounter;
    private int rating;
    private int target;
    private int progress;
    private int index;

    Task(String task, boolean isCounter, boolean isComplete, int rating, int target , int progress){
        this.isDivider = false;
        this.task = task;
        this.isComplete = isComplete;
        this.isCounter = isCounter;
        this.rating = rating;
        this.target = target;
        this.progress = progress;
        index = 0;
    }


    Task(String task,boolean isDivider){
        this.isDivider = isDivider;
        this.task = task;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public void setProgress(int progress) {
        this.progress = progress;
    }

    public int getProgress() {
        return this.progress;
    }

    public void setTarget(int target) {
        this.target = target;
    }

    public int getTarget() {
        return this.target;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public int getRating() {
        return this.rating;
    }

    public void setIsCounter(boolean counter) {
        this.isCounter = counter;
    }
    public boolean getIsCounter(){
        return this.isCounter;
    }


    public Boolean getDivide() {
        return this.isDivider;
    }
    public void setIsDivide(Boolean div){
        this.isDivider = div;
    }

    public String getTask() {
        return this.task;
    }
    public void setTask(String task) {
        this.task = task;
    }

    public boolean getIsComplete() {
        return this.isComplete;
    }
    public void setIsComplete(boolean isComplete) {
        this.isComplete = isComplete;
    }
}